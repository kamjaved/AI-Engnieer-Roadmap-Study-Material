import json
from pathlib import Path
R = Path(__file__).resolve().parent.parent
o = json.load(open(R / "layer3_postgres/psql_outputs.json"))
rd = lambda p: (R / p).read_text().rstrip("\n")
def fence(t, lang=""): return f"```{lang}\n{t}\n```"
gold = [json.loads(l) for l in rd("layer2_generated/gold_test.jsonl").splitlines()]
labels = rd("layer2_generated/gold_labels.jsonl")
nat = json.load(open(R / "layer0_raw/1_national_utilization_page0.json"))
nat_show = json.dumps([nat[0], nat[7]], indent=2)
md = f"""# ClaimLens Lite — mock data, layer by layer

*Written 22 Oct 2026 for the Simplified Plan ("Lite"). Companion to `ClaimLens_Simplified_Plan.md`.*

## 0. Read this first

- **What this is.** A small, realistic sample of the data at every layer: the 5 downloaded files, the human-curated inputs, the generated files, and the final PostgreSQL tables with 3 to 12 rows each.
- **It was actually run.** I wrote the build script, ran it on a local **PostgreSQL 16**, and pasted the real query output below. Rules R1 to R4 were executed against the tables; the findings, buckets and "dollars at risk" in the claims come from that run, not from my typing.
- **What is real and what is not.**

| Marker | Meaning |
|---|---|
| ✅ **Layout** | File layout and column names checked against a CMS page this session (PTP columns A to G, MUE four headers, ICD-10-CM order file positions, national table field names from the plan). |
| 🧪 **Illustrative values** | **Every number and most code pairs are invented to look plausible.** The utilization figures, charges, MUE values, MAI values, PTP indicators (except 29806/29822, which AAOS documents as indicator 1 since 2002-07-01) are **not CMS values**. Do not quote them. |
| ⚠️ **Placeholder text** | Policy snippets 2 and 4 are placeholders; the Policy Manual passages must be copied by your PO. I have not read the manual. |

- **The sample claims are 6 (not hundreds).** One per error slice: CLEAN, E1 (PTP), E2 (MUE), E3 (duplicate), E4 (fee outlier), E6 (note does not document a service).

---

## 1. The layers at a glance

```text
LAYER 0  RAW DOWNLOADS (5 files, never edited)
   1 national utilization (API JSON)   2 NCCI PTP (4 ZIPs)   3 NCCI MUE   4 ICD-10-CM order file   5 NCCI Policy Manual PDF
        |                                   |                    |              |                         |
        v                                   v                    v              v                         v
LAYER 1  HUMAN-CURATED INPUTS (small CSV files in git, reviewed by PO/QA)
   dx_map.csv (code -> plausible diagnoses, + mismatch list)   policy_snippets.csv (15-30 passages)   app_users.csv
        |
        v
LAYER 2  GENERATED FILES (`make data`, fixed seed, identical on every laptop)
   ref_code.csv  ref_ptp.csv  ref_mue.csv  ref_dx.csv  |  gold_test.jsonl  gold_labels.jsonl  gold_manifest.json (sha256)
        |
        v
LAYER 3  POSTGRESQL (9 tables from the plan + ref_dx + app_users)
   reference: ref_code ref_ptp ref_mue ref_dx policy_snippets app_users
   operational: claims claim_lines findings reviews audit_events
        |
        v
LAYER 4  RUNTIME OUTPUTS (written by the app while it runs)
   findings (R1-R4 + Decision-1)   memo   bucket + dollars at risk   reviews (examiner, supervisor)   audit_events
```

| Layer | Owner | Format | Size in the real project | How it is rebuilt |
|---|---|---|---|---|
| 0 | Dev 2 (once) | JSON, ZIP of txt/xlsx, CSV, fixed-width txt, PDF | National table 13,463 rows ✅; PTP is the largest file | Download again for a new quarter |
| 1 | PO + QA | CSV in git | ~300 dx_map rows, 15 to 30 snippets | Edit and review in pull requests |
| 2 | Dev 2 | CSV + JSONL | ~300 codes; 300 gold + 300 dev claims | `make data` (fixed seed) |
| 3 | Dev 3 | PostgreSQL | Hundreds of PTP rows after filtering; hundreds of claims | `make seed` (idempotent load) |
| 4 | The app | PostgreSQL rows | Grows with use | Not rebuilt; append-only audit |

**Hard rule:** labels (`gold_labels.jsonl`) are **never** loaded into PostgreSQL. The app must not be able to see the answer key.

---

## 2. Layer 0 — the five downloads, as they look

### 2.1 National utilization table (data.cms.gov API) → JSON

- **Where:** data.cms.gov API for "Medicare Physician & Other Practitioners – by Geography and Service", filter `Rndrng_Prvdr_Geo_Lvl=National`, page with `size` and `offset`. National level has 13,463 rows ✅ (plan). Dataset id: `<dataset-uuid>` (look it up in the catalog).
- **Format:** a JSON array, **every value is a string**, including numbers.
- **We keep:** office (`O`) and facility (`F`) rows only, codes that also appear in the MUE table, top ~300 by `Tot_Srvcs`.
- **Trap:** the data is the 2023 release ✅, so a code deleted since 2023 may be missing from the MUE table; the join to MUE drops it (that is intended).

Two records (of the {len(nat)} in the sample file) 🧪:

{fence(nat_show, "json")}

### 2.2 NCCI PTP, practitioner (4 ZIPs) → tab-delimited text or xlsx

- **Where:** CMS NCCI page, "Practitioner PTP Edits", quarterly (2026 Q4 files are effective 1 Oct 2026 ✅). Accept the licence prompt if shown.
- **Layout ✅ (CMS MLN):** Column A = Column 1 code, B = Column 2 code, C = "in existence before 1996" flag, D = effective date, E = deletion date, F = modifier indicator (0, 1, 9), G = rationale category.
- **Format traps:** a few **notes rows** above the real header; dates as `YYYYMMDD`; deletion date `*` when none; four files to concatenate; if it arrives only as `.xlsx`, convert once to CSV/Parquet and never re-read the xlsx.

Sample (tabs shown as `|`), 🧪 except the first row:

{fence(rd("layer0_raw/2_ptp_practitioner_f1.txt").replace(chr(9), " | "))}

### 2.3 NCCI MUE, practitioner → CSV/xlsx

- **Layout ✅ (CMS MLN), exact four headers:** `HCPCS/CPT Code`, `Practitioner Services MUE Values`, `MUE Adjudication Indicator (MAI)`, `MUE Rationale`. There is **no modifier column** and no date column in the table.
- **Trap:** the MAI arrives as **text with its label** ("3 Date of Service Edit: Clinical"), not a bare number. We take the first character.

{fence(rd("layer0_raw/3_mue_practitioner.csv"))}

### 2.4 ICD-10-CM code descriptions (CMS/CDC "order file") → fixed-width text

- **Layout ✅ (CMS order-file layout):** order number columns 1-5; code 7-13 **without dot**; header flag column 15 (`0` = header, not valid for claims; `1` = valid); short description 17-76 (60 chars); long description from column 78. Lines are never longer than 400 characters.
- **Trap:** parse by **position**, not by splitting on spaces. Header rows (flag 0, e.g. `E11`) must not be accepted as diagnosis codes.

{fence(rd("layer0_raw/4_icd10cm_order_2027.txt"))}

### 2.5 NCCI Policy Manual (PDF) → no table at all

A PDF is **not parsed by code** in Lite. Your PO reads it and copies 15 to 30 passages into `policy_snippets.csv` (Layer 1), with chapter, section and page. That file is what the memo is allowed to cite.

---

## 3. Layer 1 — curated inputs (small, human-reviewed, in git)

### 3.1 `dx_map.csv` (also the E5 ground truth)

For each procedure code, 2 or 3 plausible diagnoses, plus a few deliberate **mismatches** for error type E5. The build **fails** if any code is missing from the ICD file or is not billable.

{fence(rd("layer1_curated/dx_map.csv"), "csv")}

### 3.2 `policy_snippets.csv`

{fence(rd("layer1_curated/policy_snippets.csv"), "csv")}

Snippet `PS-R1-01` and `PS-R2-01` are paraphrases of text from the CMS PTP and MUE web pages ✅. `PS-R1-02` and `PS-R4-01` are ⚠️ placeholders: your PO replaces them with verbatim manual passages and fills `manual_section` and `page`.

### 3.3 `app_users.csv` (dev login, Days 1 to 12)

{fence(rd("layer1_curated/app_users.csv"), "csv")}

---

## 4. Layer 2 — what the build produces

### 4.1 Build log (real output)

{fence(rd("layer3_postgres/build_log.txt"))}

Reading the log: 10 national rows kept (9 codes, 99213 appears as both `O` and `F`); 9 MUE rows kept (27447 dropped: not in the vocabulary); **PTP 7 rows in, 5 kept**. The two dropped PTP rows are `29806/29822` and `27447/27486`, because one of their codes is not in our vocabulary. The rule: **both codes must be in `ref_code`**, otherwise the E1 injector could not place the pair on a claim.

### 4.2 `ref_code.csv` (first rows)

{fence(chr(10).join(rd("layer2_generated/ref_code.csv").splitlines()[:5]), "csv")}

`units_per_day` = `Tot_Srvcs` ÷ `Tot_Bene_Day_Srvcs`. For 97140 that is 22,500,000 ÷ 9,300,000 = **2.42 units a day** 🧪, which is what the generator samples around for clean claims.

### 4.3 `ref_ptp.csv`, `ref_mue.csv`, `ref_dx.csv`

{fence(rd("layer2_generated/ref_ptp.csv"), "csv")}

{fence(rd("layer2_generated/ref_mue.csv"), "csv")}

{fence(rd("layer2_generated/ref_dx.csv"), "csv")}

Notice `97110 / 97140` has a **deletion date of 2024-01-01**. It is in the table on purpose: a claim with a 2026 date of service must **not** be flagged by it (claim 103 below proves that).

### 4.4 The gold file: `gold_test.jsonl` (one claim per line, no answers inside)

Claim 102 (E1 slice) as stored:

{fence(json.dumps(gold[1], indent=2), "json")}

The NPIs are **valid** (they pass the Luhn check with prefix 80840 ✅). The patient is a token, never a real person.

### 4.5 `gold_labels.jsonl` (the answer key, kept outside the database)

{fence(labels, "json")}

### 4.6 `gold_manifest.json` (freeze record)

{fence(rd("layer2_generated/gold_manifest.json"), "json")}

On Day 6 the team freezes the file, records the SHA-256, and **never tunes on it**. The real project has 300 gold claims and a second 300-claim dev set with a different seed.

### 4.7 How each error slice is made (the six in this sample)

| Slice | Injector action | Sample claim | What the rules/AI should do |
|---|---|---|---|
| CLEAN | Nothing; rejected if it trips any rule | 101 | GREEN |
| E1 | Add the Column 2 code of an active PTP pair on the same date | 102 | R1 flags line 2 |
| E2 | Units above the MUE | 103 | R2 flags line 2 |
| E3 | Copy a line | 105 | R3 flags the copy |
| E4 | Multiply a charge by 4 to 8× (here 6×) | 106 | R4 soft flag |
| E6 | Note that omits a billed service | 104 | Decision-1 `note_documents_all_services` low |

---

## 5. Layer 3 — the final PostgreSQL tables

Schema file: `layer3_postgres/schema.sql`. Row counts after the load:

{fence(o["counts"])}

Short IDs below (8 characters) are the first part of a UUID; the database stores the full value.

### 5.1 `ref_code`  (10 rows, 3 shown)
{fence(o["ref_code"])}
Primary key `(code, place_of_srvc)`. `avg_sbmtd_chrg` is the baseline for rule R4.

### 5.2 `ref_ptp`  (5 rows, all shown)
{fence(o["ref_ptp"])}
Empty `del` = still active (`deletion_date IS NULL`). `table_version` ties every finding to the quarter that produced it.

### 5.3 `ref_mue`  (9 rows, 3 shown)
{fence(o["ref_mue"])}

### 5.4 `ref_dx`  (6 rows, 3 shown)  — *addition to the plan, see section 8*
{fence(o["ref_dx"])}

### 5.5 `policy_snippets`  (4 rows, 3 shown)
{fence(o["policy_snippets"])}

### 5.6 `app_users`  (3 rows)  — *addition to the plan*
{fence(o["app_users"])}

### 5.7 `claims`  (6 rows)
{fence(o["claims"])}

One row in full (claim 102, expanded). Note `raw_payload` (the claim exactly as received), `memo` (JSON), `trace_id`, and `synthetic = t`:

{fence(o["claim_row_x"])}

### 5.8 `claim_lines`  (11 rows)
{fence(o["claim_lines"])}

### 5.9 `findings`  (12 rows, the 6 that matter shown)
{fence(o["findings"])}

One rule finding in full (R1 on claim 102):

{fence(o["finding_row_x"])}

One AI finding in full (Decision-1 on claim 104). In the real project these numbers come from the model; **here they are mock values**:

{fence(o["finding_ai_x"])}

### 5.10 `reviews`  (3 rows)
{fence(o["reviews"])}

### 5.11 `audit_events`  (33 rows, claim 102 shown)
{fence(o["audit_events"])}

Plain append-only table: the app role gets INSERT and SELECT only (no UPDATE or DELETE). Lite has no hash chain.

---

## 6. Layer 4 — what the run did to the six claims

| Claim | Slice | What happened | Bucket | At risk |
|---|---|---|---|---|
| 101 | CLEAN | No rule hit. Note check p = 0.93 (INFO). Examiner approved. | GREEN | $0.00 |
| 102 | E1 | R1: `29881` → `29877` is an **indicator 0** pair, so `RT` does not bypass. Examiner recommended denial, supervisor (a different person) confirmed. | RED | $1,150.00 |
| 103 | E2 | R2: 97140 has **8 units**, MUE is 4 (MAI 3). The pair `97110/97140` was **not** flagged because its deletion date (2024-01-01) is before the date of service. | RED | $544.00 |
| 104 | E6 | No rule hit. Decision-1 `p(documented) = 0.41`: top option 0.59 is below 0.60, so it is in the **uncertain band**. | AMBER | $45.00 |
| 105 | E3 | R3: line 2 duplicates line 1. | RED | $92.00 |
| 106 | E4 | R4: $870.00 vs average $145.20 (6×, threshold 3×). Soft flag. | AMBER | $870.00 |

**The queue query** (RED first, then AMBER, by dollars at risk) for claims waiting for review:

{fence(o["queue_query"])}

**Four-eyes proof** (the two actions on claim 102 come from two different users and roles):

{fence(o["four_eyes"])}

---

## 7. One fact, traced from download to decision

```text
CMS PTP file row   29881 | 29877 | * | 20120101 | * | 0 | ...        (Layer 0, illustrative)
  -> filter: both codes in vocabulary                                  (Layer 2 build)
  -> ref_ptp row  (29881, 29877, 2012-01-01, NULL, '0', NCCI-2026Q4)   (Layer 3)
  -> claim 102 has lines 29881 and 29877 on 2026-10-06                 (gold_test.jsonl -> claims)
  -> R1 joins the pair, date 2012-01-01 <= DOS < no deletion           (rule run)
  -> finding R1_PTP, HARD, details = the matched row, table_version    (findings)
  -> bucket RED, at risk $1,150.00                                     (claims)
  -> memo cites PS-R1-01 and PS-R1-02                                  (claims.memo)
  -> examiner RECOMMEND_DENIAL (NCCI-PTP) -> supervisor CONFIRM_DENIAL (reviews + audit_events)
```

Every arrow is a row you can query, which is what makes the denial memo defensible.

---

## 8. What building this sample exposed (decisions for the team)

| # | Finding | Why it matters | Suggested resolution |
|---|---|---|---|
| 1 | The plan's 9 tables have **no home for ICD-10 descriptions**, but Decision-1 needs `dx_desc`. | Without it the AI input is missing text. | Add the tiny `ref_dx` table (built from `dx_map` × ICD file). |
| 2 | The plan puts the memo "on findings", but a memo is **per claim**. | Duplicating it across findings invites inconsistency. | Store it as `claims.memo` (used here). Your call. |
| 3 | The dev login needs **seeded users**, which are not in the 9 tables. | Four-eyes needs two distinct actor IDs. | Add `app_users` (used here), or a config file. |
| 4 | **Rule numbering differs.** Blueprint 1: R3 = fee outlier, R4 = duplicate. Lite: **R3 = duplicate, R4 = fee outlier**. | Mixed numbering breaks tests, reason codes and the UI prototype. | Pick one scheme now and rename in code and docs. |
| 5 | The plan says "SQLite fallback, avoid Postgres-only features", but this schema uses `text[]`, `jsonb`, `uuid`. | The fallback will not run this DDL. | Either drop the SQLite fallback, or store arrays/JSON as JSON text and uuid as text. Decide on Day 1. |
| 6 | **Most NPIs in the React prototype fail the Luhn check.** Of 8 distinct NPIs in its mock claims, only 2 pass (`1245319599`, `1679543219`); `1234567890` is the deliberate bad one. | A real validator would reject claims 00104, 00089, 00108 and 00119 on arrival, and claim 00042 has one failing NPI (`1982654328`). | Generate NPIs with the prefix-80840 Luhn rule (the build script has `make_npi`). |
| 7 | Rules R1/R2 will score ~100% on this gold set by construction (the injector and the rules read the same tables). | The plan already warns about this (§3.5). | Report false-positive rate and Decision-1 accuracy instead. |
| 8 | `dollars_at_risk` = sum of charges on flagged lines (Blueprint rule). For E2 this counts the **whole** 97140 line ($544), not just the excess units. | It overstates the amount at risk. | Keep for the demo; note it. A tighter rule could price only units above the MUE. |
| 9 | Time zones: timestamps are stored `timestamptz` in UTC. | The UI must convert to local time. | Convert only in the UI. |
| 10 | The R4 threshold (`k = 3`) is **my assumption**; the plan only says "compare to `Avg_Sbmtd_Chrg`". | E4 multiplies by 4 to 8×, so 3× catches it, but false positives on legitimate high charges are possible. | Make `k` a config value; tune on the dev set, not on gold. |

---

## 9. Re-run it yourself

The folder `claimlens_lite_sample/` (zip) contains the raw files, curated files, generated files, schema, both scripts and the saved psql output.

```bash
# needs a PostgreSQL 14+ server you can create a database on
uv init sample && cd sample && uv add "psycopg[binary]"
export CLAIMLENS_ADMIN_DSN="host=localhost user=postgres dbname=postgres"
export CLAIMLENS_DSN="host=localhost user=postgres dbname=claimlens_lite"
uv run python tools/build_all.py      # raw -> generated -> PostgreSQL, runs R1-R4
uv run python tools/dump.py           # re-creates the query outputs shown above
```

The scripts drop and recreate the database `claimlens_lite`, so run them against a throw-away server.

---

## Sources for the layouts

- CMS, [How to use the Medicare NCCI, chapter 2](https://www.cms.gov/Outreach-and-Education/MLN/Educational-Tools/MLN901346-How-to-use-the-Medicare-NCCI/ncci-medicare/chapter_2_using_the_ncci_tools/) (PTP columns A to G; MUE table's four headers)
- CMS, [ICD-10-CM/PCS order files layout](https://www.cms.gov/files/document/icd-10-cm-pcs-order-files-fy17-pdf.pdf) (fixed-width positions)
- CMS, [Medicare NCCI PTP edits](https://www.cms.gov/medicare/coding-billing/national-correct-coding-initiative-ncci-edits/medicare-ncci-procedure-procedure-ptp-edits) and [MUE](https://www.cms.gov/medicare/coding-billing/national-correct-coding-initiative-ncci-edits/medicare-ncci-medically-unlikely-edits) pages (definitions, quarterly files)
- AAOS, [What is NCCI PTP](https://www.aaos.org/globalassets/quality-and-practice-resources/coding-and-reimbursement/resident-guide/resident-guide-coding-reference-tools_what-is-ncci-ptp.pdf) (29806/29822, indicator 1)
- John D. Cook, [NPI and its checksum](https://www.johndcook.com/blog/2024/06/26/npi-number/)
- `ClaimLens_Simplified_Plan.md` §3 to §5 (national table fields and counts, generator steps, table list)
"""
out = Path("/home/claude/ClaimLens_Lite_Data_Layers_Mock_Samples.md")
out.write_text(md)
print(len(md.split()), "words")
