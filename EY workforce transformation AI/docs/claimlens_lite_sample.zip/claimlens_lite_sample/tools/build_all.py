"""Mini end-to-end build for the ClaimLens Lite sample: raw files -> generated files -> PostgreSQL.
Everything numeric in layer0 is ILLUSTRATIVE (not CMS values). Only the layouts follow CMS."""
import csv, json, hashlib, os, uuid, datetime as dt, re
from pathlib import Path
import psycopg
from psycopg.types.json import Jsonb

ROOT = Path(__file__).resolve().parent.parent
L0, L1, L2, L3 = (ROOT / n for n in ("layer0_raw", "layer1_curated", "layer2_generated", "layer3_postgres"))
TV = "NCCI-2026Q4"                       # quarterly table version (files effective 1 Oct 2026)
RELEASE = "CMS-PUF-National-2023"
NS = uuid.UUID("12345678-1234-5678-1234-567812345678")
def uid(name): return uuid.uuid5(NS, name)
def D(s): return dt.date.fromisoformat(s)
log = []

# ---------- NPI with valid Luhn check digit (prefix 80840) ----------
def npi_check(first9):
    total = 0
    for i, ch in enumerate(reversed("80840" + first9)):
        d = int(ch) * (2 if i % 2 == 0 else 1)
        total += d - 9 if d > 9 else d
    return (10 - total % 10) % 10
def make_npi(first9): return first9 + str(npi_check(first9))
assert make_npi("199399999") == "1993999998"           # worked example from the NPI checksum article

# ---------- LAYER 0 -> LAYER 2: reference tables ----------
mue_rows = []
with open(L0 / "3_mue_practitioner.csv", newline="") as f:
    next(f)                                              # skip title row
    for r in csv.DictReader(f):
        mue_rows.append(dict(code=r["HCPCS/CPT Code"], mue_value=int(r["Practitioner Services MUE Values"]),
                             mai=int(r["MUE Adjudication Indicator (MAI)"].split()[0]),
                             rationale=r["MUE Rationale"], table_version=TV))
mue_codes = {r["code"] for r in mue_rows}

nat = json.load(open(L0 / "1_national_utilization_page0.json"))
ref_code = []
for r in nat:
    if r["Place_Of_Srvc"] not in ("O", "F") or r["HCPCS_Cd"] not in mue_codes: continue
    ts, bd = int(r["Tot_Srvcs"]), int(r["Tot_Bene_Day_Srvcs"])
    ref_code.append(dict(code=r["HCPCS_Cd"], place_of_srvc=r["Place_Of_Srvc"], description=r["HCPCS_Desc"],
        tot_srvcs=ts, tot_bene_day_srvcs=bd, units_per_day=round(ts / bd, 2), avg_sbmtd_chrg=r["Avg_Sbmtd_Chrg"],
        avg_mdcr_alowd_amt=r["Avg_Mdcr_Alowd_Amt"], avg_mdcr_pymt_amt=r["Avg_Mdcr_Pymt_Amt"], source_release=RELEASE))
vocab = {r["code"] for r in ref_code}
log.append(f"national rows in: {len(nat)}  kept (O/F and in MUE): {len(ref_code)}  distinct codes: {len(vocab)}")

mue_rows = [r for r in mue_rows if r["code"] in vocab]
log.append(f"MUE rows kept (code in vocabulary): {len(mue_rows)}")

ptp_rows, ptp_in = [], 0
lines = (L0 / "2_ptp_practitioner_f1.txt").read_text().splitlines()
hdr = next(i for i, l in enumerate(lines) if l.startswith("Column 1"))     # skip the notes rows
for l in lines[hdr + 1:]:
    c = l.split("\t"); ptp_in += 1
    if c[0] not in vocab or c[1] not in vocab: continue                     # both codes must be in our vocabulary
    ptp_rows.append(dict(column1=c[0], column2=c[1], effective_date=dt.datetime.strptime(c[3], "%Y%m%d").date().isoformat(),
        deletion_date="" if c[4].strip() in ("*", "") else dt.datetime.strptime(c[4], "%Y%m%d").date().isoformat(),
        modifier_indicator=c[5], rationale=c[6], table_version=TV))
log.append(f"PTP rows in: {ptp_in}  kept (both codes in vocabulary): {len(ptp_rows)}")

icd = {}
for l in (L0 / "4_icd10cm_order_2027.txt").read_text().splitlines():          # fixed-width: 1-5, 7-13, 15, 17-76, 78-
    icd[l[6:13].strip()] = dict(code=l[6:13].strip(), short_desc=l[16:76].strip(), long_desc=l[77:].strip(),
                                billable=(l[14] == "1"), table_version="ICD10CM-FY2027")
dx_map = list(csv.DictReader(open(L1 / "dx_map.csv")))
bad = [r for r in dx_map if r["icd10_code"] not in icd or not icd[r["icd10_code"]]["billable"]]
assert not bad, bad                                                         # build fails if the curated map has an invalid code
ref_dx = [icd[c] for c in sorted({r["icd10_code"] for r in dx_map})]
log.append(f"dx_map rows: {len(dx_map)}  all valid+billable; ref_dx rows: {len(ref_dx)}")

def write_csv(path, rows):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
write_csv(L2 / "ref_code.csv", ref_code); write_csv(L2 / "ref_ptp.csv", ptp_rows)
write_csv(L2 / "ref_mue.csv", mue_rows); write_csv(L2 / "ref_dx.csv", ref_dx)

# ---------- DB: schema + reference load ----------
DSN = os.environ.get("CLAIMLENS_ADMIN_DSN", "host=/tmp port=5544 user=postgres dbname=postgres")
DSN_DB = os.environ.get("CLAIMLENS_DSN", "host=/tmp port=5544 user=postgres dbname=claimlens_lite")
conn = psycopg.connect(DSN, autocommit=True)
conn.execute("DROP DATABASE IF EXISTS claimlens_lite"); conn.execute("CREATE DATABASE claimlens_lite"); conn.close()
conn = psycopg.connect(DSN_DB)
conn.execute((L3 / "schema.sql").read_text())
def ins(table, rows):
    cols = list(rows[0]); q = f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join(['%s']*len(cols))})"
    with conn.cursor() as cur:
        for r in rows: cur.execute(q, [None if v == "" else v for v in r.values()])
ins("ref_code", ref_code); ins("ref_ptp", ptp_rows); ins("ref_mue", mue_rows); ins("ref_dx", ref_dx)
ins("policy_snippets", list(csv.DictReader(open(L1 / "policy_snippets.csv"))))
users = {r["role"]: dict(id=str(uid("user-" + r["role"])), **r) for r in csv.DictReader(open(L1 / "app_users.csv"))}
ins("app_users", [dict(id=u["id"], name=u["name"], role=u["role"]) for u in users.values()])

# ---------- rules R1-R4 (pure SQL lookups + Python logic) ----------
BYPASS = {"59", "XE", "XS", "XP", "XU", "LT", "RT", "FA", "TA", "T1", "T2", "F1", "F2"}
FEE_K = 3.0                                                                  # R4 threshold, config (assumption)
def run_rules(claim):
    out, ls = [], claim["lines"]
    for a in ls:                                                             # R1: ordered pairs
        for b in ls:
            if a is b or a["dos"] != b["dos"] or a["rendering_npi"] != b["rendering_npi"]: continue
            row = conn.execute("""SELECT column1,column2,effective_date,deletion_date,modifier_indicator,table_version FROM ref_ptp
                WHERE column1=%s AND column2=%s AND effective_date<=%s AND (deletion_date IS NULL OR %s<deletion_date)""",
                (a["code"], b["code"], a["dos"], a["dos"])).fetchone()
            if not row or row[4] == "9": continue
            ok = row[4] == "1" and (BYPASS & set(a["modifiers"] + b["modifiers"]))
            if row[4] == "0" or not ok:
                out.append(dict(check_id="R1_PTP", check_type="RULE", severity="HARD", line_nos=[b["line_no"]],
                    details=dict(column1=row[0], column2=row[1], effective_date=str(row[2]), deletion_date=None,
                                 modifier_indicator=row[4], modifiers_seen=a["modifiers"] + b["modifiers"],
                                 why="indicator 0: no modifier can bypass" if row[4] == "0" else "indicator 1 but no valid modifier"),
                    table_version=row[5]))
    for code in sorted({l["code"] for l in ls}):                             # R2: MUE
        m = conn.execute("SELECT mue_value,mai,table_version FROM ref_mue WHERE code=%s", (code,)).fetchone()
        if not m: continue
        same = [l for l in ls if l["code"] == code]
        groups = [[l] for l in same] if m[1] == 1 else [same]                # MAI 1: per line; MAI 2/3: sum per date of service
        for g in groups:
            tot = sum(l["units"] for l in g)
            if tot > m[0]:
                out.append(dict(check_id="R2_MUE", check_type="RULE", severity="HARD", line_nos=[l["line_no"] for l in g],
                    details=dict(code=code, mue_value=m[0], mai=m[1], units_summed=tot), table_version=m[2]))
    seen = {}
    for l in ls:                                                             # R3: duplicate (within claim in this sample)
        k = (l["code"], l["dos"], l["rendering_npi"], tuple(sorted(l["modifiers"])))
        if k in seen and not ({"76", "77", "91"} & set(l["modifiers"])):
            out.append(dict(check_id="R3_DUP", check_type="RULE", severity="HARD", line_nos=[l["line_no"]],
                            details=dict(duplicate_of_line=seen[k], key=list(map(str, k))), table_version=None))
        seen.setdefault(k, l["line_no"])
    for l in ls:                                                             # R4: fee outlier vs avg submitted charge
        pos = "O" if l["place_of_service"] == "11" else "F"
        base = conn.execute("SELECT avg_sbmtd_chrg FROM ref_code WHERE code=%s AND place_of_srvc=%s", (l["code"], pos)).fetchone()
        if base and l["charge"] / l["units"] > FEE_K * float(base[0]):
            out.append(dict(check_id="R4_FEE", check_type="RULE", severity="SOFT", line_nos=[l["line_no"]],
                details=dict(charge_per_unit=round(l["charge"] / l["units"], 2), avg_sbmtd_chrg=float(base[0]), k=FEE_K), table_version=RELEASE))
    return out

# ---------- claim specs (what the generator emits) ----------
BILL_NPI, REND_NPI = make_npi("145739281"), make_npi("124531959")
def L(n, code, mods, units, charge, dx, pos="11", dos="2026-10-05"):
    return dict(line_no=n, dos=dos, place_of_service=pos, code=code, modifiers=mods, units=units, charge=charge, dx_codes=dx, rendering_npi=REND_NPI)
SPECS = [
 dict(ref="SYN-837P-000101", label="CLEAN", pt="SYN-PT-000412", age=72, sex="F", dos="2026-10-05", status="APPROVED",
      lines=[L(1, "99214", [], 1, 198.00, ["E119"]), L(2, "36415", [], 1, 14.00, ["E119"])],
      note="72-year-old female, routine diabetes follow-up. Feels well. A1c reviewed with the patient and medication plan discussed. Venous blood drawn today for repeat labs. Return in 3 months.",
      ai_note=0.93),
 dict(ref="SYN-837P-000102", label="E1", pt="SYN-PT-000977", age=64, sex="M", dos="2026-10-06", status="DENIAL_CONFIRMED",
      lines=[L(1, "29881", ["RT"], 1, 2400.00, ["M23211"], pos="22", dos="2026-10-06"),
             L(2, "29877", ["RT"], 1, 1150.00, ["M23211"], pos="22", dos="2026-10-06")], note=None, ai_note=None),
 dict(ref="SYN-837P-000103", label="E2", pt="SYN-PT-001203", age=58, sex="F", dos="2026-10-07", status="READY_FOR_REVIEW",
      lines=[L(1, "97110", [], 3, 252.00, ["M5450"], dos="2026-10-07"), L(2, "97140", [], 8, 544.00, ["M5450"], dos="2026-10-07")],
      note=None, ai_note=None),
 dict(ref="SYN-837P-000105", label="E3", pt="SYN-PT-000208", age=61, sex="F", dos="2026-10-09", status="READY_FOR_REVIEW",
      lines=[L(1, "97530", [], 1, 92.00, ["M1711"], dos="2026-10-09"), L(2, "97530", [], 1, 92.00, ["M1711"], dos="2026-10-09")],
      note=None, ai_note=None),
 dict(ref="SYN-837P-000106", label="E4", pt="SYN-PT-000555", age=70, sex="F", dos="2026-10-09", status="READY_FOR_REVIEW",
      lines=[L(1, "99213", [], 1, 870.00, ["I10"], dos="2026-10-09")], note=None, ai_note=None),
 dict(ref="SYN-837P-000104", label="E6", pt="SYN-PT-000731", age=69, sex="M", dos="2026-10-08", status="READY_FOR_REVIEW",
      lines=[L(1, "99214", [], 1, 205.00, ["I10"], dos="2026-10-08"), L(2, "93000", [], 1, 45.00, ["I10"], dos="2026-10-08")],
      note="69-year-old male with hypertension, here for blood pressure follow-up. BP 142/88 today. Discussed diet and medication adherence. Continue current dose; recheck in 6 weeks.",
      ai_note=0.41),
]
AI_VERSION, AI_MODEL, Q_SET = "decision1-claimlens", "decision1-claimlens", "qset-lite-v1"

def bucket_of(findings):
    if any(f["severity"] == "HARD" for f in findings) or any(f["check_id"] == "AI_NOTE_DOC" and f["details"]["p_true"] < 0.30 for f in findings): return "RED"
    if any(f["severity"] == "SOFT" for f in findings): return "AMBER"
    return "GREEN"

gold, labels = [], []
T0 = dt.datetime(2026, 10, 12, 8, 15, tzinfo=dt.timezone.utc)
for i, s in enumerate(SPECS):
    cid = uid("claim-" + s["ref"]); s["id"] = cid
    payload = dict(external_ref=s["ref"], patient=dict(token=s["pt"], age=s["age"], sex=s["sex"]), billing_npi=BILL_NPI, dos_from=s["dos"], dos_to=s["dos"],
                   lines=s["lines"], encounter_note=s["note"])
    gold.append(payload); labels.append(dict(claim_ref=s["ref"], error_type=s["label"]))
    s["payload"] = payload
(L2 / "gold_test.jsonl").write_text("\n".join(json.dumps(g) for g in gold) + "\n")
lab_exp = {"E1": dict(line_nos=[2], expected_check_id="R1_PTP", expected_flag=True),
           "E2": dict(line_nos=[2], expected_check_id="R2_MUE", expected_flag=True),
           "E6": dict(line_nos=[2], expected_check_id="AI_NOTE_DOC", expected_flag=True),
           "E3": dict(line_nos=[2], expected_check_id="R3_DUP", expected_flag=True),
           "E4": dict(line_nos=[1], expected_check_id="R4_FEE", expected_flag=True),
           "CLEAN": dict(line_nos=[], expected_check_id=None, expected_flag=False)}
(L2 / "gold_labels.jsonl").write_text("\n".join(json.dumps({**l, **lab_exp[l["error_type"]]}) for l in labels) + "\n")
sha = hashlib.sha256((L2 / "gold_test.jsonl").read_bytes()).hexdigest()
(L2 / "gold_manifest.json").write_text(json.dumps(dict(file="gold_test.jsonl", claims=len(gold), seed=20261008, table_version=TV,
    frozen_on="2026-10-08 (Day 6)", sha256=sha), indent=2) + "\n")

# ---------- pipeline per claim: rules -> AI (mock Decision-1) -> bucket -> memo -> persist ----------
MEMOS = {
 "E1": dict(summary="Line 2 (29877) is the Column 2 code of a PTP pair with line 1 (29881). The edit has modifier indicator 0, so the RT modifier cannot bypass it.",
            suggested_action="recommend_denial", citations=["PS-R1-01", "PS-R1-02"], model_deployment="chat-claimlens", prompt_version="memo-lite-v1"),
 "E2": dict(summary="Line 2 (97140) bills 8 units. The MUE for 97140 is 4 (MAI 3). The pair 97110/97140 is in the PTP table but was deleted on 2024-01-01, so it is not applied.",
            suggested_action="request_records", citations=["PS-R2-01"], model_deployment="chat-claimlens", prompt_version="memo-lite-v1"),
 "E6": dict(summary="Decision-1 gives p(documented)=0.41 for the billed services. The note does not mention an ECG, so line 2 (93000) may be undocumented. Request the tracing.",
            suggested_action="request_records", citations=[], model_deployment="chat-claimlens", prompt_version="memo-lite-v1"),
 "E3": dict(summary="Line 2 repeats line 1: same patient, code (97530), date, rendering NPI and modifiers, with no repeat-procedure modifier (76/77/91).",
            suggested_action="recommend_denial", citations=[], model_deployment="chat-claimlens", prompt_version="memo-lite-v1"),
 "E4": dict(summary="Line 1 (99213) is billed at $870.00, six times the national average submitted charge of $145.20. Soft flag: ask the provider to confirm the charge.",
            suggested_action="request_records", citations=["PS-R4-01"], model_deployment="chat-claimlens", prompt_version="memo-lite-v1"),
 "CLEAN": dict(summary="No findings. Template summary (0 LLM tokens).", suggested_action="approve", citations=[], model_deployment="TEMPLATE", prompt_version="template-green-v1"),
}
claim_findings, event_seq = {}, []
for i, s in enumerate(SPECS):
    created = T0 + dt.timedelta(minutes=7 * i)
    fs = run_rules(s)
    ai_dx = dict(check_id="AI_DX_SUPPORT", check_type="AI", severity="INFO", line_nos=[l["line_no"] for l in s["lines"]],
                 details=dict(question="diagnosis_supports_services", choice="supports", probs=dict(supports=0.88, does_not_support=0.05, cannot_tell=0.07)), table_version=None)
    fs.append(ai_dx)
    if s["ai_note"] is not None:
        p = s["ai_note"]; flagged = p < 0.60 and max(p, 1 - p) < 0.60
        fs.append(dict(check_id="AI_NOTE_DOC", check_type="AI", severity="SOFT" if flagged else "INFO", line_nos=[2] if flagged else [1, 2],
                       details=dict(question="note_documents_all_services", p_true=p, p_false=round(1 - p, 2), uncertain_band=flagged), table_version=None))
    s["findings"] = fs; s["bucket"] = bucket_of(fs)
    s["risk"] = sum(l["charge"] for l in s["lines"] if any(l["line_no"] in f["line_nos"] for f in fs if f["severity"] in ("HARD", "SOFT")))
    s["created"] = created; s["updated"] = created + dt.timedelta(hours=2 if s["status"] != "READY_FOR_REVIEW" else 0, minutes=3)
    s["total"] = sum(l["charge"] for l in s["lines"])
    s["memo"] = MEMOS[s["label"]]
    conn.execute("""INSERT INTO claims (id,external_ref,source,status,bucket,dollars_at_risk,patient_token,patient_age,patient_sex,billing_npi,
        dos_from,dos_to,total_charge,raw_payload,encounter_note,memo,trace_id,synthetic,created_at,updated_at)
        VALUES (%s,%s,'json',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,true,%s,%s)""",
        (s["id"], s["ref"], s["status"], s["bucket"], s["risk"], s["pt"], s["age"], s["sex"], BILL_NPI, s["dos"], s["dos"], s["total"],
         Jsonb(s["payload"]), s["note"], Jsonb(s["memo"]), hashlib.md5(str(s["id"]).encode()).hexdigest(), created, s["updated"]))
    for l in s["lines"]:
        conn.execute("INSERT INTO claim_lines VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (s["id"], l["line_no"], l["dos"], l["place_of_service"], l["code"], l["modifiers"], l["units"], l["charge"], l["dx_codes"], l["rendering_npi"]))
    for k, f in enumerate(fs, 1):
        f["id"] = uid(f"finding-{s['ref']}-{k}")
        conn.execute("INSERT INTO findings VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (f["id"], s["id"], f["line_nos"], f["check_id"], f["check_type"], f["severity"], Jsonb(f["details"]), f["table_version"],
             AI_MODEL if f["check_type"] == "AI" else None, Q_SET if f["check_type"] == "AI" else None, created + dt.timedelta(seconds=20 + k)))
    def ev(actor, etype, payload, when, **kw):
        conn.execute("INSERT INTO audit_events (claim_id,actor,event_type,payload,model_deployment,prompt_version,table_version,created_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",
                     (s["id"], actor, etype, Jsonb(payload), kw.get("m"), kw.get("p"), kw.get("t"), when))
    ev("system", "CLAIM_RECEIVED", dict(source="json", external_ref=s["ref"]), created)
    ev("system", "RULES_RUN", dict(findings=[f["check_id"] for f in fs if f["check_type"] == "RULE"]), created + dt.timedelta(seconds=20), t=TV)
    ev("system", "DECISION1_SCORED", dict(questions=[f["details"].get("question") for f in fs if f["check_type"] == "AI"]), created + dt.timedelta(seconds=24), m=AI_MODEL, p=Q_SET)
    ev("system", "BUCKETED", dict(bucket=s["bucket"], dollars_at_risk=s["risk"]), created + dt.timedelta(seconds=26))
    ev("system", "MEMO_GENERATED", dict(suggested_action=s["memo"]["suggested_action"]), created + dt.timedelta(seconds=40), m=s["memo"]["model_deployment"], p=s["memo"]["prompt_version"])
    s["created_dt"] = created

def review(s, who, action, reason, comment, mins, fids=None):
    when = s["created"] + dt.timedelta(minutes=mins); u = users[who]
    conn.execute("INSERT INTO reviews VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)", (uid(f"rev-{s['ref']}-{action}"), s["id"], u["id"], who, action, reason, fids, comment, when))
    conn.execute("INSERT INTO audit_events (claim_id,actor,event_type,payload,created_at) VALUES (%s,%s,%s,%s,%s)",
                 (s["id"], u["name"], "REVIEW_" + action, Jsonb(dict(reason_code=reason, comment=comment)), when))
s1, s2 = SPECS[0], SPECS[1]
review(s1, "Examiner", "APPROVE", None, "No findings. GREEN claim, approved.", 25)
r1 = [f["id"] for f in s2["findings"] if f["check_id"] == "R1_PTP"]
review(s2, "Examiner", "RECOMMEND_DENIAL", "NCCI-PTP", "Line 2 is Column 2 of an indicator-0 pair with line 1; RT does not bypass.", 30, r1)
review(s2, "Supervisor", "CONFIRM_DENIAL", "NCCI-PTP", "Confirmed. Pair verified in table NCCI-2026Q4.", 95, r1)
conn.commit()
(L3 / "build_log.txt").write_text("\n".join(log) + "\n")
print("\n".join(log))
