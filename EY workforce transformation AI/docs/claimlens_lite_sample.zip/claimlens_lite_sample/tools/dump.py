import subprocess, json, os
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent; OUT = ROOT / "layer3_postgres"
Q = {
 "ref_code": "select code, place_of_srvc pos, left(description,38) description, tot_srvcs, units_per_day upd, avg_sbmtd_chrg sbmtd, avg_mdcr_alowd_amt allowed from ref_code where (code,place_of_srvc) in (('99213','O'),('97140','O'),('29881','F')) order by code",
 "ref_ptp": "select column1 col1, column2 col2, effective_date eff, deletion_date del, modifier_indicator ind, left(rationale,32) rationale, table_version from ref_ptp order by column1, column2",
 "ref_mue": "select code, mue_value, mai, rationale, table_version from ref_mue where code in ('97140','99213','29881') order by code",
 "ref_dx": "select code, left(short_desc,48) short_desc, billable, table_version from ref_dx where code in ('E119','M23211','H259') order by code",
 "policy_snippets": "select id, rule_id, left(text,70) || '...' text, left(source_doc,34) source_doc, manual_section sect, page from policy_snippets order by id limit 3",
 "app_users": "select left(id::text,8) id, name, role from app_users order by role",
 "claims": "select left(id::text,8) id, external_ref, status, bucket, dollars_at_risk risk, total_charge total, patient_token, billing_npi, dos_from, (encounter_note is not null) has_note, (memo is not null) has_memo, synthetic syn from claims order by external_ref",
 "claim_lines": "select left(claim_id::text,8) claim, line_no ln, dos, place_of_service pos, code, modifiers, units, charge, dx_codes, rendering_npi from claim_lines order by claim_id, line_no",
 "findings": "select left(id::text,8) id, left(claim_id::text,8) claim, check_id, severity sev, line_nos, table_version tv, left(details::text,86) details from findings where severity<>'INFO' or check_id='AI_NOTE_DOC' order by (select external_ref from claims c where c.id=findings.claim_id), check_id",
 "reviews": "select left(id::text,8) id, left(claim_id::text,8) claim, actor_role role, action, reason_code reason, left(comment,52) comment, created_at from reviews order by created_at",
 "audit_events": "select a.id, left(a.claim_id::text,8) claim, a.actor, a.event_type, a.model_deployment model, a.prompt_version prompt, a.table_version tv, to_char(a.created_at,'MM-DD HH24:MI:SS') at from audit_events a join claims c on c.id=a.claim_id where c.external_ref='SYN-837P-000102' order by a.id",
 "counts": "select 'ref_code' t, count(*) from ref_code union all select 'ref_ptp',count(*) from ref_ptp union all select 'ref_mue',count(*) from ref_mue union all select 'ref_dx',count(*) from ref_dx union all select 'policy_snippets',count(*) from policy_snippets union all select 'app_users',count(*) from app_users union all select 'claims',count(*) from claims union all select 'claim_lines',count(*) from claim_lines union all select 'findings',count(*) from findings union all select 'reviews',count(*) from reviews union all select 'audit_events',count(*) from audit_events",
}
def psql(sql, x=False):
    cmd = ["psql","-h","/tmp","-p","5544","-U","postgres","-d","claimlens_lite","-P","pager=off","-c",sql] + (["-x"] if x else [])
    return subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, "PGTZ": "UTC"}).stdout.rstrip()
res = {k: psql(v) for k, v in Q.items()}
res["claim_row_x"] = psql("select id, external_ref, source, status, bucket, dollars_at_risk, patient_token, patient_age, patient_sex, billing_npi, dos_from, dos_to, total_charge, raw_payload, encounter_note, memo, trace_id, synthetic, created_at, updated_at from claims where external_ref='SYN-837P-000102'", x=True)
res["finding_row_x"] = psql("select * from findings where claim_id=(select id from claims where external_ref='SYN-837P-000102') and check_id='R1_PTP'", x=True)
res["finding_ai_x"] = psql("select check_id, severity, line_nos, details, model_deployment, question_set_version from findings where claim_id=(select id from claims where external_ref='SYN-837P-000104') and check_id='AI_NOTE_DOC'", x=True)
res["four_eyes"] = psql("select r.action, u.name, r.actor_role from reviews r join app_users u on u.id=r.actor_id where r.claim_id=(select id from claims where external_ref='SYN-837P-000102') order by r.created_at")
res["queue_query"] = psql("select external_ref, bucket, dollars_at_risk, status from claims where status in ('READY_FOR_REVIEW') order by case bucket when 'RED' then 0 when 'AMBER' then 1 else 2 end, dollars_at_risk desc")
json.dump(res, open(OUT / "psql_outputs.json", "w"), indent=1)
print({k: len(v) for k, v in res.items()})
