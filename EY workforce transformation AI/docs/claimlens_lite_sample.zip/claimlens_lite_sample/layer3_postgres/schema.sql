-- ClaimLens "Lite" schema. 9 tables from the Simplified Plan + 2 small additions (ref_dx, app_users).
-- Python 3.14 / SQLAlchemy / Alembic would own this in the real repo; plain SQL here so it can be read and run.

-- ---------- reference data (versioned, loaded by `make data`) ----------
CREATE TABLE ref_code (
  code               text    NOT NULL,
  place_of_srvc      char(1) NOT NULL CHECK (place_of_srvc IN ('O','F')),   -- O = office, F = facility
  description        text    NOT NULL,
  tot_srvcs          bigint  NOT NULL,
  tot_bene_day_srvcs bigint  NOT NULL,
  units_per_day      numeric(6,2) NOT NULL,           -- tot_srvcs / tot_bene_day_srvcs
  avg_sbmtd_chrg     numeric(10,2) NOT NULL,          -- baseline for rule R4 (fee outlier)
  avg_mdcr_alowd_amt numeric(10,2),
  avg_mdcr_pymt_amt  numeric(10,2),
  source_release     text    NOT NULL,                -- e.g. 'CMS-PUF-National-2023'
  PRIMARY KEY (code, place_of_srvc)
);

CREATE TABLE ref_ptp (
  column1 text NOT NULL, column2 text NOT NULL,
  effective_date date NOT NULL, deletion_date date,                 -- NULL = still active
  modifier_indicator char(1) NOT NULL CHECK (modifier_indicator IN ('0','1','9')),
  rationale text, table_version text NOT NULL
);
CREATE INDEX ix_ptp_pair ON ref_ptp (column1, column2);

CREATE TABLE ref_mue (
  code text PRIMARY KEY, mue_value int NOT NULL CHECK (mue_value >= 0),
  mai smallint NOT NULL CHECK (mai IN (1,2,3)),
  rationale text, table_version text NOT NULL
);

CREATE TABLE ref_dx (                                   -- ADDITION: descriptions Decision-1 needs; built from dx_map x ICD file
  code text PRIMARY KEY, short_desc text NOT NULL, long_desc text NOT NULL,
  billable boolean NOT NULL, table_version text NOT NULL
);

CREATE TABLE policy_snippets (
  id text PRIMARY KEY, rule_id text NOT NULL, text text NOT NULL,
  source_doc text NOT NULL, manual_section text, page text, source_url text
);

CREATE TABLE app_users (                                -- ADDITION: seeded users for the dev login (Days 1-12)
  id uuid PRIMARY KEY, name text NOT NULL, role text NOT NULL CHECK (role IN ('Examiner','Supervisor','Admin'))
);

-- ---------- operational data ----------
CREATE TABLE claims (
  id uuid PRIMARY KEY,
  external_ref text NOT NULL UNIQUE,
  source text NOT NULL CHECK (source IN ('json')),
  status text NOT NULL CHECK (status IN ('RECEIVED','PROCESSING','READY_FOR_REVIEW','APPROVED','RECORDS_REQUESTED',
                                         'DENIAL_RECOMMENDED','DENIAL_CONFIRMED','FAILED')),
  bucket text CHECK (bucket IN ('RED','AMBER','GREEN')),
  dollars_at_risk numeric(12,2) NOT NULL DEFAULT 0,
  patient_token text NOT NULL, patient_age smallint, patient_sex char(1),
  billing_npi char(10) NOT NULL,
  dos_from date NOT NULL, dos_to date NOT NULL, total_charge numeric(12,2) NOT NULL,
  raw_payload jsonb NOT NULL,                           -- the claim exactly as received
  encounter_note text,                                  -- "note as a column"
  memo jsonb,                                           -- DEVIATION: memo is per claim, so it sits here, not on findings
  trace_id text,                                        -- Application Insights trace
  synthetic boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL, updated_at timestamptz NOT NULL
);
CREATE INDEX ix_claims_queue ON claims (status, bucket, dollars_at_risk DESC);

CREATE TABLE claim_lines (
  claim_id uuid NOT NULL REFERENCES claims(id), line_no smallint NOT NULL,
  dos date NOT NULL, place_of_service char(2) NOT NULL,
  code text NOT NULL, modifiers text[] NOT NULL DEFAULT '{}',
  units int NOT NULL CHECK (units >= 1), charge numeric(10,2) NOT NULL,
  dx_codes text[] NOT NULL, rendering_npi char(10) NOT NULL,
  PRIMARY KEY (claim_id, line_no)
);
CREATE INDEX ix_lines_history ON claim_lines (rendering_npi, dos, code);

CREATE TABLE findings (
  id uuid PRIMARY KEY, claim_id uuid NOT NULL REFERENCES claims(id),
  line_nos smallint[] NOT NULL,
  check_id text NOT NULL,                               -- R1_PTP, R2_MUE, R3_DUP, R4_FEE, AI_NOTE_DOC, AI_DX_SUPPORT
  check_type text NOT NULL CHECK (check_type IN ('RULE','AI')),
  severity text NOT NULL CHECK (severity IN ('HARD','SOFT','INFO')),
  details jsonb NOT NULL,                               -- matched table row, or option probabilities
  table_version text, model_deployment text, question_set_version text,
  created_at timestamptz NOT NULL
);

CREATE TABLE reviews (
  id uuid PRIMARY KEY, claim_id uuid NOT NULL REFERENCES claims(id),
  actor_id uuid NOT NULL REFERENCES app_users(id), actor_role text NOT NULL,
  action text NOT NULL CHECK (action IN ('APPROVE','REQUEST_RECORDS','RECOMMEND_DENIAL','CONFIRM_DENIAL','RETURN_DENIAL')),
  reason_code text, finding_ids uuid[], comment text,
  created_at timestamptz NOT NULL
);

CREATE TABLE audit_events (                             -- plain append-only (no hash chain in Lite)
  id bigserial PRIMARY KEY, claim_id uuid REFERENCES claims(id),
  actor text NOT NULL, event_type text NOT NULL, payload jsonb NOT NULL,
  model_deployment text, prompt_version text, table_version text,
  created_at timestamptz NOT NULL
);
