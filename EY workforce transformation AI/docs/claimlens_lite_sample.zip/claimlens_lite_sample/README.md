# claimlens_lite_sample

Mock data for every layer of the ClaimLens Lite plan. All values are illustrative (see the main document).

- `layer0_raw/` the five downloads as they look (the Policy Manual PDF has no file; it is copied by hand)
- `layer1_curated/` dx_map, policy_snippets, app_users
- `layer2_generated/` ref_*.csv, gold_test.jsonl, gold_labels.jsonl, gold_manifest.json
- `layer3_postgres/` schema.sql, build_log.txt, psql_outputs.json
- `tools/build_all.py` raw -> generated -> PostgreSQL (runs rules R1-R4); `tools/dump.py`; `tools/mkdoc.py`

Run: set CLAIMLENS_ADMIN_DSN and CLAIMLENS_DSN, then `python tools/build_all.py`. It drops and recreates the database claimlens_lite.
